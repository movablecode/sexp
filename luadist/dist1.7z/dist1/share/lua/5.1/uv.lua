return require 'uv/init'
