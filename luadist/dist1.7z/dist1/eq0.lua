--  base0.lua
local cl = io.popen"cd":read'*l'

local function write_format(...)
  io.write(string.format(...))
end
local function write_format_flush(...)
  io.write(string.format(...))
  io.flush()
end
wf = write_format
wff = write_format_flush
sf = string.format


SCRDIR = sf("%s\\scr0",cl)

local a = sf("%s\\share\\lua\\5.1",cl)
package.path = sf(".\\?.lua;%s\\?.lua;%s\\?.lua;%s\\?.luac;%s\\?\\init.lua",
    SCRDIR,a,a,a)
a = sf("%s\\lib\\lua\\5.1",cl)
package.cpath = sf(".\\?.dll;%s\\?.dll;%s\\?.dll;",
    a,a,a)

require "lfs"
require "lpeg"
require "moonscript"

function file_exist(fname)
  local f = io.open(fname,"r")
  if f~=nil then  f:close()  return true  end
  return false
end

function get_file_ext(fname)
  local va = split(fname,"[.]")
  return va[#va]
end

--  Push HEAD
function push_head(q,v)
    table.insert(q,1,v)
end

--  Push TAIL
function push_tail(q,v)
    q[#q+1]=v
end

--  Pop HEAD
function pop_head(q)
    local item=nil
    if (#q>0) then   item = q[1]   table.remove(q,1)  end
    return item
end

--  Pop TAIL
function pop_tail(q)
    local item=nil
    if (#q>0) then   item= q[#q]   table.remove(q,#q)  end
    return item
end


shell=io.popen
function instant_shell(...)  local output = shell(sf(...))  output:close()  end

moon = require "moonscript.base"
do_moonfile = function (fname)
  local fn = assert(moon.loadfile(fname))
  if (fn==nil) then
    print ("error",fname)
  else
    return fn()
  end
end
execl_script = function (fname,eb)
  if (fname==nil) then
    return
  end
  eb = eb or 0
  if (eb>0) then
    fname = sf("%s/%s",SCRDIR,fname)
    local fn0 = fname..".moon"
    if file_exist(fn0) then
      do_moonfile(fn0)
    else
      fn0 = fname..".lua"
      dofile(fn0)
    end
  else
    if file_exist(fname) then
      local ext = get_file_ext(fname)
      if (ext=="moon") then
        do_moonfile(fname)
      else
        dofile(fname)
      end
    end
  end
end

local fn = {
  --  do embedded script
  e = function ()
    local item = pop_head(arg)
    execl_script (item, 1)
  end,
  --  do file script
  f = function ()
    print ("called f")
  end,
  --  print env
  p = function ()
    print ("----")
    print ("path = ",package.path)
    print ("cpath = ",package.cpath)
    print ("----")
  end,
  --  test libraries
  test_lib = function ()
    require "ansicolors"
    print ("done")
  end,
  --  unit test
  test_unit = function ()
    -- require "busted.runner"()
    print (arg,#arg)
    require 'busted.runner'({ batch = true })
  end,
}
if (#arg>0) then
  local f = fn[arg[1]]
  if (type(f)=="function") then
    pop_head(arg)
    f ()
  else
    print (arg,#arg)
  end
end
